"""Allow running as: python -m mcp_server_rabel"""
from .server import main

if __name__ == "__main__":
    main()
